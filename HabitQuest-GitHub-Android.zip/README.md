# HabitQuest Android (GitHub Actions)

This repository packages the supplied HabitQuest HTML app as an Android APK using Capacitor 7.

## Repository contents

- `www/index.html` — the HabitQuest web app
- `package.json` — matching Capacitor 7 dependencies
- `capacitor.config.json` — Android app ID, app name and web directory
- `.github/workflows/build-apk.yml` — cloud APK build workflow

## Build the APK

1. Create a GitHub repository named `HabitQuest`.
2. Upload the contents of this folder to the repository root (not the folder itself).
3. Make sure the default branch is named `main`.
4. Open the repository's **Actions** tab.
5. Select **Build HabitQuest Android APK**.
6. Tap **Run workflow** and select `main`.
7. Wait for the workflow to finish successfully.
8. Open the successful workflow run and download the `HabitQuest-debug-APK` artifact.
9. Extract the downloaded ZIP. It contains `app-debug.apk`.

The workflow also runs automatically whenever you push changes to `main`.

## Important

- This workflow builds a **debug APK** for personal testing, not a signed Play Store release.
- The HTML app currently loads Tailwind, Lucide, Tone.js and Google Fonts from external CDNs. Those features need an internet connection unless the assets are later bundled locally.
- If the build fails, open the failed workflow run, expand the first red step, and share the complete error text. A build cannot be guaranteed until GitHub runs it successfully.
